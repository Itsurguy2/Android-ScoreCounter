package com.example.scorecounter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class WinnerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_winner);

        TextView winner = findViewById(R.id.winner);
        TextView score = findViewById(R.id.score);

        Intent intent = getIntent();
        String winnerstr = intent.getStringExtra("winner_name");
        String scorestr = intent.getStringExtra("winner_score");

        winner.setText(winnerstr);
        score.setText("Won by " + scorestr + " points!");
    }
}